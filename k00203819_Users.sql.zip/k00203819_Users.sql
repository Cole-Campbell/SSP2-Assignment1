-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 08, 2016 at 09:59 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` int(10) NOT NULL,
  `stock` int(4) NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `img`) VALUES
(1, 'Box of Imps', 'This box of imps is amazing! I have never seen so many imps. It is crazy!', 25, 4, 'img/boxofimps.jpg'),
(2, 'Big Box of Imps', 'This box of imps is amazing! I have never seen so many imps. It is crazy!', 25, 4, 'img/boxofimps.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `date_joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `date_joined`) VALUES
(2, 'Cole', 'b7a875fc1ea228b9061041b7cec4bd3c52ab3ce3', '', '2016-11-06 11:42:55'),
(3, 'Colle', 'e80b2d2608711cbb3312db7c4727a46fbad9601a', 'llll@gmail.com', '2016-11-06 11:43:10'),
(4, 'Steven', 'b7a875fc1ea228b9061041b7cec4bd3c52ab3ce3', 'steven@gmail.com', '2016-11-06 11:43:04'),
(5, 'Po', '6880aa7be2aa9880386d8c50d16adf6cd52d229b', 'cole@gmail.com', '2016-11-06 12:59:38'),
(7, 'Paul', 'e80b2d2608711cbb3312db7c4727a46fbad9601a', 'cole.william.campbell@gmail.com', '2016-11-06 11:49:45'),
(16, 'Paula', '7072df1b0e70d64a4c2a2aacbf0f32bf61165b1b', 'll@gmail.com', '2016-11-06 11:55:41'),
(18, 'Paulaaa', '7e240de74fb1ed08fa08d38063f6a6a91462a815', 'll@gmail.coma', '2016-11-06 12:19:21'),
(19, 'Heather', '42525bb6d3b0dc06bb78ae548733e8fbb55446b3', 'heather@gmail.com', '2016-11-06 13:05:47'),
(20, 'liz', 'c40dbb01a0ae2ed2db5ce64b57b4492867839e53', 'lizzyc154@hotmail.com', '2016-11-08 08:57:35'),
(21, 'liza', '78f8bb4c43c7c3e4e5883e8e9b18518c89d965ff', 'lizzyc154@hotmail.ca', '2016-11-08 08:56:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `[username]` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
